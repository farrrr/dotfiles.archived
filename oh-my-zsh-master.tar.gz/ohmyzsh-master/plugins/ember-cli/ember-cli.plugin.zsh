# Ember CLI
# Visit https://www.ember-cli.com/ to view user guide

alias es='ember serve'
alias ea='ember addon'
alias eb='ember build'
alias ed='ember destroy'
alias eg='ember generate'
alias eh='ember help'
alias ein='ember init'
alias ei='ember install'
alias et='ember test'
alias ets='ember test --serve'
alias eu='ember update'

# version
alias ev='ember version'
