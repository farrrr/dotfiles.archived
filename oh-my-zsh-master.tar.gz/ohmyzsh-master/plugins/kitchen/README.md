# kitchen plugin

This plugin adds completion support for the [Test Kitchen](https://kitchen.ci).

To use it, add `kitchen` to the plugins array in your zshrc file:

```zsh
plugins=(... kitchen)
```
